/**
 * New typescript file
 */


import { Book } from './book';
export const BOOKS :Book[]=[{
    id:1,title:"Accidental PrimeMinister",
    author:'Sanjay',price:750
    
  },{
    id:2,title:"Not Without My Daughter",
    author:'Betty Mehmoodi',price:550
    
  },{
    id:3,title:"My Family,All I Have",
    author:'Unknown',price:400
    
  }]
