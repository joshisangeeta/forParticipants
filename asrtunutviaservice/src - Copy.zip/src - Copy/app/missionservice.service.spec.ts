import { TestBed, inject } from '@angular/core/testing';

import { MissionserviceService } from './missionservice.service';

describe('MissionserviceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MissionserviceService]
    });
  });

  it('should be created', inject([MissionserviceService], (service: MissionserviceService) => {
    expect(service).toBeTruthy();
  }));
});
