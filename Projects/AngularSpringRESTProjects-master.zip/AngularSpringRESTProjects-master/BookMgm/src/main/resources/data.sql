delete from book;
insert into book(id,title,author,price) values(1,'Accidental PrimeMinister','Sanjay',750);
insert into book(id,title,author,price) values(2,'Not Without My Daughter','Betty Mehmoodi',550);
insert into book(id,title,author,price) values(3,'My Family,All I Have','Unknown',400);




 