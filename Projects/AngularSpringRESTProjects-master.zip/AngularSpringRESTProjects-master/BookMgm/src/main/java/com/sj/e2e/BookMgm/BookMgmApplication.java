package com.sj.e2e.BookMgm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookMgmApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookMgmApplication.class, args);
	}
}
