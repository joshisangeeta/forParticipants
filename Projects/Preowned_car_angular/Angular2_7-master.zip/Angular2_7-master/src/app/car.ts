export class Car {

 id:number;
 model:string;
 yearsOfUse:number;
 color:string;
 price : number;

    
}