var myArray = [1,2,3,4];
var x = myArray.filter((val)=>(val % 2 )== 0).map((val)=>val*val).reduce((previousValue,currentValue)=>previousValue+currentValue);
console.log(x);