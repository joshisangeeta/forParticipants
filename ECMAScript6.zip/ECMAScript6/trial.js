var messages = ["msg1","msg2","msg3"];
 var cat ={
     say:function(str){
         console.log(str);
     }
 }

 for(let i=0;i<messages.length;i++){
     //cat.say(messages[i]);
    setTimeout(function(){cat.say(messages[i])},i*4000);



 }
