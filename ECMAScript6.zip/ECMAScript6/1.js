console.log(eval("2+2"));
var obj ={
    'name': "sj"
    
}