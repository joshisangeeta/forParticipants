var promise1 = new Promise(function(resolve,rejct){
    setInterval(resolve('foo'), 3000);
});

promise1.then(function(value){console.log(value)})
console.log(promise1);