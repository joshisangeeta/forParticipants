
//demo 1:
/*
var elements = ['Hydrogen',
'Helium',
'Lithium',
'Beryllium'];

console.log("Length of each element:"+elements.map((ele)=>ele.length));
*/
//Demo 2:
/*
function Person(){

    this.age=0;

    setInterval(function growUp(){
              this.age++;
              console.log(this.age);
    },1000)
}

var p1 = new Person();*/

//Demo2 -a
/*
function Person(){

    this.age=0;
   var that=this;
    setInterval(function growUp(){
             // that.age++;
             console.log(that.age++);
    },1000)
}

var p1 = new Person(); */
//Demo 2 -b Using Arrow functions
/*function Person(){

    this.age=0;
  
    setInterval(()=>{
            
             console.log(this.age++);
    },1000)
}









var p1 = new Person(); */

//Demo 2 -c Using bind functions
function Person(){

    this.age=0;
  
}

var p1 = new Person();
growUp=function(){
  // this.age=0;
    this.age++;
     console.log(  this.age);
}

//p1.growUp();    throws error

 setInterval(growUp.bind(p1),1000);

